# AngularMaterialBlitz

Angular 13.2.6
Angular Material: 13.2.6
